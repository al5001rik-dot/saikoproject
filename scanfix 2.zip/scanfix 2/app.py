"""ScanFix — веб-система учёта оборудования Колледжа ДГУ."""
from __future__ import annotations

import io
import os
import secrets
from collections import Counter
from datetime import datetime
from functools import wraps

import qrcode
from flask import (
    Flask,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)
from flask_login import LoginManager, current_user, login_required, login_user, logout_user

from ai import CATEGORIES, analyze_problem
from models import (
    ActionLog,
    Equipment,
    InventoryCheck,
    InventorySession,
    KnowledgeBase,
    Location,
    Ticket,
    TicketHistory,
    User,
    db,
)

TICKET_TRANSITIONS = {
    "Новая": ["На рассмотрении", "В работе", "Отклонена"],
    "На рассмотрении": ["В работе", "Нужны уточнения", "Отклонена"],
    "В работе": ["Нужны уточнения", "Решена", "Отклонена"],
    "Нужны уточнения": ["На рассмотрении", "В работе", "Отклонена"],
    "Решена": [],
    "Отклонена": [],
}

EQUIP_STATUSES = ["Исправно", "Неисправно", "На обслуживании"]
EQUIP_TYPES = ["Компьютер", "Монитор", "Проектор", "Принтер", "Другое"]
COMMENT_REQUIRED = {"Нужны уточнения", "Отклонена", "Решена"}


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "scanfix-hackathon-demo-key")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + os.path.join(
        os.path.abspath(os.path.dirname(__file__)), "scanfix.db"
    )
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["BASE_URL"] = os.environ.get("BASE_URL", "").rstrip("/")

    db.init_app(app)
    login_manager = LoginManager(app)
    login_manager.login_view = "login"
    login_manager.login_message = "Войдите как сотрудник, чтобы открыть панель."

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    @app.context_processor
    def inject_globals():
        new_count = 0
        if current_user.is_authenticated:
            new_count = Ticket.query.filter_by(status="Новая").count()
        return {
            "EQUIP_STATUSES": EQUIP_STATUSES,
            "EQUIP_TYPES": EQUIP_TYPES,
            "CATEGORIES": CATEGORIES,
            "new_tickets_count": new_count,
            "status_class": status_class,
            "equip_status_class": equip_status_class,
        }

    def status_class(status: str) -> str:
        return {
            "Новая": "st-new",
            "На рассмотрении": "st-review",
            "В работе": "st-progress",
            "Нужны уточнения": "st-clarify",
            "Решена": "st-done",
            "Отклонена": "st-rejected",
        }.get(status, "st-review")

    def equip_status_class(status: str) -> str:
        return {
            "Исправно": "st-done",
            "Неисправно": "st-rejected",
            "На обслуживании": "st-progress",
        }.get(status, "st-review")

    def base_url() -> str:
        return app.config["BASE_URL"] or request.url_root.rstrip("/")

    def make_qr_png(url: str):
        img = qrcode.make(url)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        buf.seek(0)
        return buf

    def log_action(equipment_id: int, action: str, details: str) -> None:
        db.session.add(
            ActionLog(
                user_id=current_user.id if current_user.is_authenticated else None,
                equipment_id=equipment_id,
                action=action,
                details=details,
            )
        )

    # ── Public ──────────────────────────────────────────────

    @app.route("/")
    def home():
        demos = (
            Equipment.query.order_by(Equipment.inventory_number)
            .limit(6)
            .all()
        )
        return render_template("home.html", demos=demos)

    @app.route("/phone")
    def phone_shell():
        demo = Equipment.query.filter_by(inventory_number="ПК-001").first()
        demo_url = url_for("equipment_public", qr_key=demo.qr_key) if demo else "/"
        return render_template("phone_shell.html", demo_url=demo_url)

    @app.route("/search")
    def search_equipment():
        q = (request.args.get("q") or "").strip()
        if not q:
            flash("Введите инвентарный номер", "warning")
            return redirect(url_for("home"))
        eq = Equipment.query.filter(Equipment.inventory_number.ilike(q)).first()
        if not eq:
            flash(f"Устройство с номером «{q}» не найдено", "danger")
            return redirect(url_for("home"))
        return redirect(url_for("equipment_public", qr_key=eq.qr_key))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if current_user.is_authenticated:
            return redirect(url_for("admin_dashboard"))
        error = None
        if request.method == "POST":
            login_val = (request.form.get("login") or "").strip()
            password = request.form.get("password") or ""
            user = User.query.filter_by(login=login_val).first()
            if user and user.check_password(password):
                login_user(user)
                next_url = request.args.get("next") or url_for("admin_dashboard")
                return redirect(next_url)
            error = "Неверный логин или пароль"
        return render_template("login.html", error=error)

    @app.route("/logout")
    @login_required
    def logout():
        logout_user()
        flash("Вы вышли из системы", "success")
        return redirect(url_for("home"))

    @app.route("/e/<qr_key>")
    def equipment_public(qr_key):
        eq = Equipment.query.filter_by(qr_key=qr_key).first()
        if not eq:
            return render_template(
                "error.html",
                title="QR-код не найден в системе",
                message="Возможно, наклейка устарела или код повреждён. Обратитесь к ответственному сотруднику.",
            ), 404
        tickets = (
            Ticket.query.filter_by(equipment_id=eq.id)
            .order_by(Ticket.created_at.desc())
            .limit(5)
            .all()
        )
        return render_template("equipment_public.html", eq=eq, tickets=tickets)

    @app.route("/e/<qr_key>/report", methods=["GET", "POST"])
    def report_problem(qr_key):
        eq = Equipment.query.filter_by(qr_key=qr_key).first()
        if not eq:
            return render_template(
                "error.html",
                title="QR-код не найден в системе",
                message="Возможно, наклейка устарела или код повреждён.",
            ), 404

        if "form_key" not in session:
            session["form_key"] = secrets.token_urlsafe(16)

        if request.method == "POST":
            action = request.form.get("action")
            if action == "solved":
                flash("Хорошо, что проблема решилась!", "success")
                return redirect(url_for("equipment_public", qr_key=qr_key))

            form_key = request.form.get("form_key")
            if not form_key or form_key != session.get("form_key"):
                flash("Форма уже отправлена. Откройте страницу заново.", "warning")
                return redirect(url_for("equipment_public", qr_key=qr_key))

            author = (request.form.get("author_name") or "").strip()
            title = (request.form.get("title") or "").strip()
            description = (request.form.get("description") or "").strip()
            category = (request.form.get("category") or "").strip() or None
            danger = request.form.get("danger") == "1"
            ai_advice = request.form.get("ai_advice") or ""

            errors = []
            if not author:
                errors.append("Укажите ваше имя")
            if len(description) < 10:
                errors.append("Описание должно быть не короче 10 символов")
            if not title:
                title = f"Проблема с {eq.name}"

            if errors:
                for e in errors:
                    flash(e, "danger")
                return render_template(
                    "report.html",
                    eq=eq,
                    form_key=session["form_key"],
                    form=request.form,
                )

            used = Ticket.query.filter_by(form_key=form_key).first()
            if used:
                flash("Эта заявка уже создана", "warning")
                return redirect(url_for("ticket_status", token=used.public_token))

            ticket = Ticket(
                equipment_id=eq.id,
                author_name=author,
                title=title[:200],
                description=description,
                category=category,
                status="Новая",
                danger=danger,
                public_token=secrets.token_urlsafe(16),
                form_key=form_key,
                ai_advice=ai_advice,
            )
            db.session.add(ticket)
            db.session.flush()
            db.session.add(
                TicketHistory(
                    ticket_id=ticket.id,
                    status="Новая",
                    comment="Заявка создана" + (" (опасность)" if danger else ""),
                    actor_id=None,
                )
            )
            db.session.commit()
            session.pop("form_key", None)
            flash(f"Заявка №{ticket.id} создана", "success")
            return redirect(url_for("ticket_status", token=ticket.public_token))

        return render_template("report.html", eq=eq, form_key=session["form_key"], form={})

    @app.route("/e/<qr_key>/ai-check", methods=["POST"])
    def ai_check(qr_key):
        eq = Equipment.query.filter_by(qr_key=qr_key).first_or_404()
        data = request.get_json(silent=True) or {}
        description = (data.get("description") or "").strip()
        kb = KnowledgeBase.query.all()
        result = analyze_problem(description, kb, equipment_name=eq.name)
        return jsonify(result)

    @app.route("/t/<token>")
    def ticket_status(token):
        ticket = Ticket.query.filter_by(public_token=token).first()
        if not ticket:
            return render_template(
                "error.html",
                title="Ссылка на заявку недействительна",
                message="Проверьте адрес или откройте ссылку, которую получили после отправки заявки.",
            ), 404
        return render_template("ticket_status.html", ticket=ticket)

    # ── Admin ───────────────────────────────────────────────

    @app.route("/admin")
    @login_required
    def admin_dashboard():
        total = Equipment.query.count()
        by_status = {
            s: Equipment.query.filter_by(status=s).count() for s in EQUIP_STATUSES
        }
        open_tickets = Ticket.query.filter(
            Ticket.status.notin_(["Решена", "Отклонена"])
        ).count()
        done_tickets = Ticket.query.filter_by(status="Решена").count()

        loc_counts = []
        for loc in Location.query.order_by(Location.building, Location.room).all():
            loc_counts.append({"label": loc.short(), "count": len(loc.equipment)})

        freq = (
            db.session.query(Equipment, db.func.count(Ticket.id).label("cnt"))
            .outerjoin(Ticket)
            .group_by(Equipment.id)
            .order_by(db.desc("cnt"))
            .limit(5)
            .all()
        )
        recent = Ticket.query.order_by(Ticket.created_at.desc()).limit(5).all()
        return render_template(
            "admin/dashboard.html",
            total=total,
            by_status=by_status,
            open_tickets=open_tickets,
            done_tickets=done_tickets,
            loc_counts=loc_counts,
            freq=freq,
            recent=recent,
        )

    @app.route("/admin/equipment")
    @login_required
    def admin_equipment():
        q = (request.args.get("q") or "").strip()
        typ = request.args.get("type") or ""
        location_id = request.args.get("location_id") or ""
        status = request.args.get("status") or ""

        query = Equipment.query
        if q:
            like = f"%{q}%"
            query = query.filter(
                db.or_(
                    Equipment.name.ilike(like),
                    Equipment.inventory_number.ilike(like),
                )
            )
        if typ:
            query = query.filter_by(type=typ)
        if location_id:
            query = query.filter_by(location_id=int(location_id))
        if status:
            query = query.filter_by(status=status)

        items = query.order_by(Equipment.inventory_number).all()
        locations = Location.query.order_by(Location.building, Location.room).all()
        return render_template(
            "admin/equipment_list.html",
            items=items,
            locations=locations,
            filters={"q": q, "type": typ, "location_id": location_id, "status": status},
        )

    @app.route("/admin/equipment/new", methods=["GET", "POST"])
    @app.route("/admin/equipment/<int:eq_id>/edit", methods=["GET", "POST"])
    @login_required
    def admin_equipment_form(eq_id=None):
        eq = db.session.get(Equipment, eq_id) if eq_id else None
        locations = Location.query.order_by(Location.building, Location.room).all()
        if request.method == "POST":
            name = (request.form.get("name") or "").strip()
            typ = request.form.get("type") or ""
            inv = (request.form.get("inventory_number") or "").strip()
            location_id = request.form.get("location_id")
            status = request.form.get("status") or "Исправно"
            specs = (request.form.get("specs") or "").strip()

            errors = []
            if not name:
                errors.append("Укажите название")
            if typ not in EQUIP_TYPES:
                errors.append("Выберите тип")
            if not inv:
                errors.append("Укажите инвентарный номер")
            if not location_id:
                errors.append("Выберите помещение")
            if status not in EQUIP_STATUSES:
                errors.append("Выберите состояние")

            dup = Equipment.query.filter_by(inventory_number=inv).first()
            if dup and (not eq or dup.id != eq.id):
                errors.append(f"Устройство с номером {inv} уже существует")

            if errors:
                for e in errors:
                    flash(e, "danger")
                return render_template(
                    "admin/equipment_form.html",
                    eq=eq,
                    locations=locations,
                    form=request.form,
                )

            if eq is None:
                eq = Equipment(qr_key=secrets.token_urlsafe(8))
                db.session.add(eq)
                is_new = True
            else:
                is_new = False
                old_loc = eq.location_id
                old_status = eq.status

            eq.name = name
            eq.type = typ
            eq.inventory_number = inv
            eq.location_id = int(location_id)
            eq.status = status
            eq.specs = specs

            if not is_new:
                if old_loc != eq.location_id:
                    log_action(eq.id, "move", f"Помещение изменено на {eq.location.short()}")
                if old_status != eq.status:
                    log_action(eq.id, "status_change", f"Состояние: {old_status} → {eq.status}")

            db.session.commit()
            flash("Устройство добавлено" if is_new else "Изменения сохранены", "success")
            return redirect(url_for("admin_equipment_detail", eq_id=eq.id))

        return render_template(
            "admin/equipment_form.html", eq=eq, locations=locations, form={}
        )

    @app.route("/admin/equipment/<int:eq_id>")
    @login_required
    def admin_equipment_detail(eq_id):
        eq = db.session.get(Equipment, eq_id)
        if not eq:
            flash("Устройство не найдено", "danger")
            return redirect(url_for("admin_equipment"))
        logs = (
            ActionLog.query.filter_by(equipment_id=eq.id)
            .order_by(ActionLog.created_at.desc())
            .limit(20)
            .all()
        )
        locations = Location.query.order_by(Location.building, Location.room).all()
        qr_url = f"{base_url()}/e/{eq.qr_key}"
        return render_template(
            "admin/equipment_detail.html",
            eq=eq,
            logs=logs,
            locations=locations,
            qr_url=qr_url,
        )

    @app.route("/admin/equipment/<int:eq_id>/qr.png")
    @login_required
    def admin_equipment_qr(eq_id):
        eq = db.session.get(Equipment, eq_id)
        if not eq:
            return "Not found", 404
        url = f"{base_url()}/e/{eq.qr_key}"
        buf = make_qr_png(url)
        return send_file(
            buf,
            mimetype="image/png",
            as_attachment=True,
            download_name=f"{eq.inventory_number}_qr.png",
        )

    @app.route("/admin/equipment/<int:eq_id>/quick", methods=["POST"])
    @login_required
    def admin_equipment_quick(eq_id):
        eq = db.session.get(Equipment, eq_id)
        if not eq:
            flash("Устройство не найдено", "danger")
            return redirect(url_for("admin_equipment"))
        action = request.form.get("action")
        if action == "location":
            new_loc = int(request.form.get("location_id"))
            if new_loc != eq.location_id:
                old = eq.location.short()
                eq.location_id = new_loc
                db.session.flush()
                log_action(eq.id, "move", f"Помещение: {old} → {eq.location.short()}")
                db.session.commit()
                flash("Помещение изменено", "success")
        elif action == "status":
            new_status = request.form.get("status")
            if new_status in EQUIP_STATUSES and new_status != eq.status:
                old = eq.status
                eq.status = new_status
                log_action(eq.id, "status_change", f"Состояние: {old} → {new_status}")
                db.session.commit()
                flash("Состояние изменено", "success")
        return redirect(url_for("admin_equipment_detail", eq_id=eq.id))

    @app.route("/admin/tickets")
    @login_required
    def admin_tickets():
        tab = request.args.get("tab") or "all"
        q = (request.args.get("q") or "").strip()
        query = Ticket.query.join(Equipment)
        if tab != "all":
            query = query.filter(Ticket.status == tab)
        if q:
            like = f"%{q}%"
            if q.isdigit():
                query = query.filter(
                    db.or_(
                        Ticket.id == int(q),
                        Equipment.name.ilike(like),
                        Equipment.inventory_number.ilike(like),
                    )
                )
            else:
                query = query.filter(
                    db.or_(
                        Equipment.name.ilike(like),
                        Equipment.inventory_number.ilike(like),
                        Ticket.title.ilike(like),
                    )
                )
        tickets = query.order_by(Ticket.created_at.desc()).all()
        counts = {s: Ticket.query.filter_by(status=s).count() for s in TICKET_TRANSITIONS}
        counts["all"] = Ticket.query.count()
        return render_template(
            "admin/tickets.html",
            tickets=tickets,
            tab=tab,
            q=q,
            counts=counts,
            tabs=[
                ("all", "Все"),
                ("Новая", "Новые"),
                ("На рассмотрении", "На рассмотрении"),
                ("В работе", "В работе"),
                ("Нужны уточнения", "Нужны уточнения"),
                ("Решена", "Решённые"),
                ("Отклонена", "Отклонённые"),
            ],
        )

    @app.route("/admin/tickets/<int:ticket_id>", methods=["GET", "POST"])
    @login_required
    def admin_ticket_detail(ticket_id):
        ticket = db.session.get(Ticket, ticket_id)
        if not ticket:
            flash("Заявка не найдена", "danger")
            return redirect(url_for("admin_tickets"))

        users = User.query.order_by(User.name).all()
        next_statuses = TICKET_TRANSITIONS.get(ticket.status, [])
        ask_equip_status = False

        if request.method == "POST":
            action = request.form.get("action")
            if action == "take":
                ticket.assignee_id = current_user.id
                db.session.commit()
                flash("Вы назначены исполнителем", "success")
                return redirect(url_for("admin_ticket_detail", ticket_id=ticket.id))

            if action == "equip_status":
                choice = request.form.get("equip_decision")
                if choice == "change":
                    new_status = request.form.get("equip_status")
                    if new_status in EQUIP_STATUSES and new_status != ticket.equipment.status:
                        old = ticket.equipment.status
                        ticket.equipment.status = new_status
                        log_action(
                            ticket.equipment_id,
                            "status_change",
                            f"После заявки №{ticket.id}: {old} → {new_status}",
                        )
                        db.session.commit()
                        flash("Состояние устройства обновлено", "success")
                    else:
                        flash("Состояние оставлено без изменений", "success")
                else:
                    flash("Состояние устройства оставлено как есть", "success")
                return redirect(url_for("admin_ticket_detail", ticket_id=ticket.id))

            new_status = request.form.get("status")
            comment = (request.form.get("comment") or "").strip()
            assignee_id = request.form.get("assignee_id") or None

            if new_status not in next_statuses:
                flash("Недопустимый переход статуса", "danger")
            elif new_status in COMMENT_REQUIRED and not comment:
                flash("Для этого статуса нужен комментарий", "danger")
            else:
                if assignee_id:
                    ticket.assignee_id = int(assignee_id)
                ticket.status = new_status
                ticket.updated_at = datetime.utcnow()
                if new_status == "Решена":
                    ticket.result = comment
                db.session.add(
                    TicketHistory(
                        ticket_id=ticket.id,
                        status=new_status,
                        comment=comment,
                        actor_id=current_user.id,
                    )
                )
                db.session.commit()
                flash("Статус изменён", "success")
                if new_status == "Решена":
                    ask_equip_status = True
                    return render_template(
                        "admin/ticket_detail.html",
                        ticket=ticket,
                        users=users,
                        next_statuses=[],
                        ask_equip_status=True,
                    )
                return redirect(url_for("admin_ticket_detail", ticket_id=ticket.id))

        return render_template(
            "admin/ticket_detail.html",
            ticket=ticket,
            users=users,
            next_statuses=next_statuses,
            ask_equip_status=ask_equip_status,
        )

    @app.route("/admin/locations", methods=["GET", "POST"])
    @login_required
    def admin_locations():
        if request.method == "POST":
            building = (request.form.get("building") or "").strip()
            floor = (request.form.get("floor") or "").strip()
            room = (request.form.get("room") or "").strip()
            if not building or not floor or not room:
                flash("Заполните корпус, этаж и кабинет", "danger")
            else:
                exists = Location.query.filter_by(building=building, room=room).first()
                if exists:
                    flash("Такая пара «корпус + кабинет» уже есть", "danger")
                else:
                    db.session.add(Location(building=building, floor=floor, room=room))
                    db.session.commit()
                    flash("Помещение добавлено", "success")
            return redirect(url_for("admin_locations"))

        locations = Location.query.order_by(Location.building, Location.room).all()
        return render_template("admin/locations.html", locations=locations)

    @app.route("/admin/inventory", methods=["GET", "POST"])
    @login_required
    def admin_inventory():
        locations = Location.query.order_by(Location.building, Location.room).all()
        past = (
            InventorySession.query.order_by(InventorySession.started_at.desc())
            .limit(10)
            .all()
        )
        session_id = request.args.get("session")
        inv_session = db.session.get(InventorySession, int(session_id)) if session_id else None

        if request.method == "POST":
            action = request.form.get("action")
            if action == "start":
                loc_id = int(request.form.get("location_id"))
                inv = InventorySession(
                    location_id=loc_id, started_by=current_user.id
                )
                db.session.add(inv)
                db.session.commit()
                return redirect(url_for("admin_inventory", session=inv.id))

            if action == "finish" and inv_session and not inv_session.finished_at:
                inv_session.finished_at = datetime.utcnow()
                db.session.commit()
                flash("Проверка завершена", "success")
                return redirect(url_for("admin_inventory", session=inv_session.id))

            if action == "manual" and inv_session and not inv_session.finished_at:
                eq_id = int(request.form.get("equipment_id"))
                existing = InventoryCheck.query.filter_by(
                    session_id=inv_session.id, equipment_id=eq_id
                ).first()
                if not existing:
                    db.session.add(
                        InventoryCheck(
                            session_id=inv_session.id,
                            equipment_id=eq_id,
                            manual=True,
                        )
                    )
                    db.session.commit()
                    flash("Отмечено вручную", "success")
                return redirect(url_for("admin_inventory", session=inv_session.id))

        checked_ids = set()
        expected = []
        missing = []
        if inv_session:
            expected = Equipment.query.filter_by(location_id=inv_session.location_id).all()
            checked_ids = {c.equipment_id for c in inv_session.checks}
            if inv_session.finished_at:
                missing = [e for e in expected if e.id not in checked_ids]

        return render_template(
            "admin/inventory.html",
            locations=locations,
            past=past,
            inv_session=inv_session,
            expected=expected,
            checked_ids=checked_ids,
            missing=missing,
        )

    @app.route("/admin/inventory/<int:session_id>/scan", methods=["POST"])
    @login_required
    def admin_inventory_scan(session_id):
        inv = db.session.get(InventorySession, session_id)
        if not inv or inv.finished_at:
            return jsonify({"ok": False, "message": "Сеанс неактивен"}), 400
        data = request.get_json(silent=True) or {}
        raw = (data.get("code") or "").strip()
        qr_key = raw
        if "/e/" in raw:
            qr_key = raw.rstrip("/").split("/e/")[-1].split("?")[0].split("/")[0]

        eq = Equipment.query.filter_by(qr_key=qr_key).first()
        if not eq:
            return jsonify({"ok": False, "message": "QR-код не найден в системе", "type": "unknown"})

        existing = InventoryCheck.query.filter_by(session_id=inv.id, equipment_id=eq.id).first()
        if existing:
            return jsonify({"ok": False, "message": "Уже проверено", "type": "duplicate", "equipment": eq.name})

        if eq.location_id != inv.location_id:
            if data.get("confirm_move"):
                old = eq.location.short()
                eq.location_id = inv.location_id
                log_action(eq.id, "move", f"Инвентаризация: {old} → {inv.location.short()}")
                inv.moved_count = (inv.moved_count or 0) + 1
                db.session.add(
                    InventoryCheck(session_id=inv.id, equipment_id=eq.id, manual=False)
                )
                db.session.commit()
                return jsonify(
                    {
                        "ok": True,
                        "message": f"Перемещено сюда: {eq.name}",
                        "type": "moved",
                        "equipment_id": eq.id,
                    }
                )
            return jsonify(
                {
                    "ok": False,
                    "type": "wrong_room",
                    "message": f"Это устройство числится в кабинете {eq.location.room}. Переместить сюда?",
                    "equipment_id": eq.id,
                    "equipment": eq.name,
                }
            )

        db.session.add(InventoryCheck(session_id=inv.id, equipment_id=eq.id, manual=False))
        db.session.commit()
        return jsonify(
            {
                "ok": True,
                "message": f"Проверено: {eq.name}",
                "type": "ok",
                "equipment_id": eq.id,
            }
        )

    @app.errorhandler(404)
    def not_found(e):
        return (
            render_template(
                "error.html",
                title="Страница не найдена",
                message="Такой страницы нет. Вернитесь на главную или отсканируйте QR заново.",
            ),
            404,
        )

    return app


app = create_app()


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        if User.query.count() == 0:
            from seed import seed_all

            seed_all(app)
    app.run(debug=True, host="127.0.0.1", port=5050)
