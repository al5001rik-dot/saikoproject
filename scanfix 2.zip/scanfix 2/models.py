from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class User(UserMixin, db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    login = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(40), default="employee")

    def set_password(self, password: str) -> None:
        # pbkdf2: совместимо со старым Python/macOS без hashlib.scrypt
        self.password_hash = generate_password_hash(password, method="pbkdf2:sha256")

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)


class Location(db.Model):
    __tablename__ = "locations"
    id = db.Column(db.Integer, primary_key=True)
    building = db.Column(db.String(80), nullable=False)
    floor = db.Column(db.String(20), nullable=False)
    room = db.Column(db.String(40), nullable=False)
    equipment = db.relationship("Equipment", back_populates="location")

    __table_args__ = (db.UniqueConstraint("building", "room", name="uq_building_room"),)

    def label(self) -> str:
        return f"Корпус {self.building}, каб. {self.room}"

    def short(self) -> str:
        return f"{self.building}-{self.room}"


class Equipment(db.Model):
    __tablename__ = "equipment"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    type = db.Column(db.String(80), nullable=False)
    inventory_number = db.Column(db.String(80), unique=True, nullable=False)
    specs = db.Column(db.Text, default="")
    status = db.Column(db.String(40), default="Исправно")  # Исправно / Неисправно / На обслуживании
    location_id = db.Column(db.Integer, db.ForeignKey("locations.id"), nullable=False)
    qr_key = db.Column(db.String(40), unique=True, nullable=False)
    photo = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    location = db.relationship("Location", back_populates="equipment")
    tickets = db.relationship("Ticket", back_populates="equipment", order_by="desc(Ticket.created_at)")


class Ticket(db.Model):
    __tablename__ = "tickets"
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey("equipment.id"), nullable=False)
    author_name = db.Column(db.String(120), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(80))
    photo = db.Column(db.String(255))
    status = db.Column(db.String(40), default="Новая")
    assignee_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    result = db.Column(db.Text)
    danger = db.Column(db.Boolean, default=False)
    public_token = db.Column(db.String(64), unique=True, nullable=False)
    form_key = db.Column(db.String(64), unique=True, nullable=False)
    ai_advice = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    equipment = db.relationship("Equipment", back_populates="tickets")
    assignee = db.relationship("User", foreign_keys=[assignee_id])
    history = db.relationship(
        "TicketHistory",
        back_populates="ticket",
        order_by="TicketHistory.created_at",
        cascade="all, delete-orphan",
    )


class TicketHistory(db.Model):
    __tablename__ = "ticket_history"
    id = db.Column(db.Integer, primary_key=True)
    ticket_id = db.Column(db.Integer, db.ForeignKey("tickets.id"), nullable=False)
    status = db.Column(db.String(40), nullable=False)
    comment = db.Column(db.Text, default="")
    actor_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    ticket = db.relationship("Ticket", back_populates="history")
    actor = db.relationship("User")


class InventorySession(db.Model):
    __tablename__ = "inventory_sessions"
    id = db.Column(db.Integer, primary_key=True)
    location_id = db.Column(db.Integer, db.ForeignKey("locations.id"), nullable=False)
    started_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    started_at = db.Column(db.DateTime, default=datetime.utcnow)
    finished_at = db.Column(db.DateTime)
    moved_count = db.Column(db.Integer, default=0)

    location = db.relationship("Location")
    starter = db.relationship("User")
    checks = db.relationship("InventoryCheck", back_populates="session", cascade="all, delete-orphan")


class InventoryCheck(db.Model):
    __tablename__ = "inventory_checks"
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey("inventory_sessions.id"), nullable=False)
    equipment_id = db.Column(db.Integer, db.ForeignKey("equipment.id"), nullable=False)
    checked_at = db.Column(db.DateTime, default=datetime.utcnow)
    manual = db.Column(db.Boolean, default=False)

    session = db.relationship("InventorySession", back_populates="checks")
    equipment = db.relationship("Equipment")


class KnowledgeBase(db.Model):
    __tablename__ = "knowledge_base"
    id = db.Column(db.Integer, primary_key=True)
    question = db.Column(db.String(255), nullable=False)
    answer = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(80))
    keywords = db.Column(db.String(255))


class ActionLog(db.Model):
    __tablename__ = "action_log"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    equipment_id = db.Column(db.Integer, db.ForeignKey("equipment.id"))
    action = db.Column(db.String(80), nullable=False)
    details = db.Column(db.Text, default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User")
    equipment = db.relationship("Equipment")
