"""Демо-данные ScanFix: помещения, техника, заявки, база знаний."""
from __future__ import annotations

import secrets
from datetime import datetime, timedelta

from models import (
    ActionLog,
    Equipment,
    KnowledgeBase,
    Location,
    Ticket,
    TicketHistory,
    User,
    db,
)


def _qr() -> str:
    return secrets.token_urlsafe(8)


def _token() -> str:
    return secrets.token_urlsafe(16)


def seed_all(app) -> None:
    with app.app_context():
        db.drop_all()
        db.create_all()

        admin = User(name="Администратор", login="admin", role="employee")
        admin.set_password("admin123")
        tech = User(name="Техник Иван", login="tech", role="employee")
        tech.set_password("tech123")
        db.session.add_all([admin, tech])

        locs = [
            Location(building="1", floor="2", room="214"),
            Location(building="1", floor="3", room="305"),
            Location(building="1", floor="1", room="112"),
        ]
        db.session.add_all(locs)
        db.session.flush()

        equipment_data = [
            ("Компьютер Dell OptiPlex 7090", "Компьютер", "ПК-001", locs[0], "Исправно", "i5, 16 ГБ ОЗУ, SSD 512 ГБ"),
            ("Компьютер HP ProDesk", "Компьютер", "ПК-002", locs[0], "Исправно", "i3, 8 ГБ ОЗУ, HDD 1 ТБ"),
            ("Монитор Samsung 24\"", "Монитор", "МОН-001", locs[0], "Исправно", "24\", Full HD, HDMI"),
            ("Монитор LG 22\"", "Монитор", "МОН-002", locs[0], "Неисправно", "22\", Full HD"),
            ("Проектор Epson EB-X51", "Проектор", "ПР-001", locs[0], "Исправно", "3600 лм, HDMI/VGA"),
            ("Принтер HP LaserJet", "Принтер", "ПРН-001", locs[0], "Исправно", "Ч/б, A4"),
            ("Компьютер Lenovo ThinkCentre", "Компьютер", "ПК-003", locs[1], "Исправно", "i5, 8 ГБ, SSD 256"),
            ("Компьютер Acer Veriton", "Компьютер", "ПК-004", locs[1], "На обслуживании", "i3, 8 ГБ"),
            ("Монитор Philips 27\"", "Монитор", "МОН-003", locs[1], "Исправно", "27\", QHD"),
            ("Проектор BenQ MX550", "Проектор", "ПР-002", locs[1], "Исправно", "3600 лм"),
            ("МФУ Canon MF3010", "Другое", "МФУ-001", locs[1], "Исправно", "Печать/скан/копия"),
            ("Компьютер ASUS ExpertCenter", "Компьютер", "ПК-005", locs[2], "Исправно", "i7, 16 ГБ, SSD 1 ТБ"),
            ("Компьютер Dell Vostro", "Компьютер", "ПК-006", locs[2], "Исправно", "i5, 8 ГБ"),
            ("Монитор Dell 24\"", "Монитор", "МОН-004", locs[2], "Неисправно", "24\", IPS"),
            ("Принтер Brother HL-L2340", "Принтер", "ПРН-002", locs[2], "Исправно", "Ч/б лазерный"),
        ]

        items = []
        for name, typ, inv, loc, status, specs in equipment_data:
            eq = Equipment(
                name=name,
                type=typ,
                inventory_number=inv,
                specs=specs,
                status=status,
                location_id=loc.id,
                qr_key=_qr(),
            )
            items.append(eq)
            db.session.add(eq)
        db.session.flush()

        # Индекс по инв. номеру
        by_inv = {e.inventory_number: e for e in items}
        now = datetime.utcnow()

        tickets_spec = [
            # status, inv, author, title, desc, category, danger, assignee, age_hours, comments
            (
                "Новая",
                "МОН-002",
                "Студент Алина",
                "Монитор не включается",
                "После пары монитор погас и больше не реагирует на кнопку питания.",
                "Не включается",
                False,
                None,
                2,
                [],
            ),
            (
                "На рассмотрении",
                "ПК-001",
                "Преподаватель Смирнов",
                "Компьютер долго загружается",
                "Загрузка Windows занимает больше 5 минут, программы открываются медленно.",
                "Другое",
                False,
                admin.id,
                20,
                [("На рассмотрении", "Принято в работу диагностики", admin.id)],
            ),
            (
                "В работе",
                "ПК-001",
                "Лаборант Петр",
                "Нет звука на компьютере",
                "На занятиях нет звука из колонок, значок звука в системе есть.",
                "Нет интернета или ПО",
                False,
                tech.id,
                48,
                [
                    ("На рассмотрении", "Заявка принята", admin.id),
                    ("В работе", "Проверяю драйверы звука", tech.id),
                ],
            ),
            (
                "Нужны уточнения",
                "ПР-001",
                "Студент Марат",
                "Проектор без изображения",
                "Включается, лампа горит, но на экране пусто.",
                "Нет изображения",
                False,
                tech.id,
                30,
                [
                    ("В работе", "Проверил кабель HDMI", tech.id),
                    ("Нужны уточнения", "Уточните: какой вход выбран на пульте?", tech.id),
                ],
            ),
            (
                "Решена",
                "ПРН-001",
                "Секретарь Ольга",
                "Принтер не печатает",
                "Задания уходят в очередь, но листы не выходят.",
                "Не печатает",
                False,
                tech.id,
                96,
                [
                    ("В работе", "Заменил картридж", tech.id),
                    ("Решена", "Картридж заменён, печать восстановлена", tech.id),
                ],
            ),
            (
                "Отклонена",
                "МОН-004",
                "Гость",
                "Хочу новый монитор",
                "Хочу заменить монитор на игровой.",
                "Другое",
                False,
                admin.id,
                120,
                [("Отклонена", "Это не неисправность. Замена по заявке не выполняется.", admin.id)],
            ),
        ]

        for status, inv, author, title, desc, cat, danger, assignee, hours, hist in tickets_spec:
            eq = by_inv[inv]
            t = Ticket(
                equipment_id=eq.id,
                author_name=author,
                title=title,
                description=desc,
                category=cat,
                status=status,
                assignee_id=assignee,
                danger=danger,
                public_token=_token(),
                form_key=_token(),
                created_at=now - timedelta(hours=hours),
                updated_at=now - timedelta(hours=hours - 1),
                ai_advice="Проверьте кабель питания и розетку.",
            )
            if status == "Решена":
                t.result = "Картридж заменён, печать восстановлена"
            db.session.add(t)
            db.session.flush()
            db.session.add(
                TicketHistory(
                    ticket_id=t.id,
                    status="Новая",
                    comment="Заявка создана",
                    actor_id=None,
                    created_at=t.created_at,
                )
            )
            for st, comment, actor in hist:
                db.session.add(
                    TicketHistory(
                        ticket_id=t.id,
                        status=st,
                        comment=comment,
                        actor_id=actor,
                        created_at=now - timedelta(hours=max(hours - 5, 1)),
                    )
                )

        db.session.add(
            ActionLog(
                user_id=admin.id,
                equipment_id=by_inv["ПК-004"].id,
                action="status_change",
                details="Состояние: Исправно → На обслуживании",
                created_at=now - timedelta(days=3),
            )
        )
        db.session.add(
            ActionLog(
                user_id=tech.id,
                equipment_id=by_inv["МОН-002"].id,
                action="status_change",
                details="Состояние: Исправно → Неисправно",
                created_at=now - timedelta(days=1),
            )
        )

        kb = [
            (
                "Как подключить компьютер к проектору",
                "1. Подключите HDMI или VGA кабель к компьютеру и проектору\n"
                "2. Включите проектор и выберите нужный вход (HDMI/VGA)\n"
                "3. На Windows нажмите Win+P и выберите «Повторяющийся» или «Расширить»\n"
                "4. Если нет изображения — проверьте кабель и источник",
                "Нет изображения",
                "проектор,подключ,hdmi,vga,экран",
            ),
            (
                "Что проверить, если принтер не печатает",
                "1. Убедитесь, что принтер включён и на связи\n"
                "2. Проверьте бумагу и индикатор ошибок\n"
                "3. Откройте очередь печати и снимите зависшие задания\n"
                "4. Перезапустите принтер и компьютер",
                "Не печатает",
                "принтер,не печат,картридж,бумага",
            ),
            (
                "Что делать, если компьютер не включается",
                "1. Проверьте кабель питания и розетку\n"
                "2. Попробуйте другую розетку\n"
                "3. Убедитесь, что кнопка питания нажата\n"
                "4. Не вскрывайте корпус — оформите заявку",
                "Не включается",
                "компьютер,не включа,питание,розетк",
            ),
            (
                "Что делать, если на проекторе нет изображения",
                "1. Проверьте кабель сигнала\n"
                "2. Выберите правильный вход на пульте\n"
                "3. Перезапустите проектор и источник\n"
                "4. Проверьте яркость/затвор объектива",
                "Нет изображения",
                "проектор,нет изображ,картинк,экран",
            ),
            (
                "Что делать, если нет интернета на компьютере",
                "1. Проверьте кабель сети или Wi‑Fi\n"
                "2. Перезагрузите компьютер\n"
                "3. Попробуйте открыть другую страницу\n"
                "4. Если не помогло — оформите заявку",
                "Нет интернета или ПО",
                "интернет,сеть,wifi,wi-fi",
            ),
            (
                "Как сообщить о неисправности",
                "1. Отсканируйте QR на устройстве\n"
                "2. Нажмите «Сообщить о проблеме»\n"
                "3. Опишите, что случилось, и проверьте с помощником\n"
                "4. Отправьте заявку и сохраните ссылку на статус",
                "Другое",
                "заявк,сообщить,неисправн",
            ),
            (
                "Как найти оборудование по QR-коду",
                "1. На главной нажмите «Сканировать QR-код»\n"
                "2. Наведите камеру на наклейку\n"
                "3. Или введите инвентарный номер вручную\n"
                "4. Откроется карточка устройства",
                "Другое",
                "qr,сканир,инвентар",
            ),
            (
                "Как проверить статус заявки",
                "1. После отправки откроется страница статуса\n"
                "2. Нажмите «Копировать ссылку» и сохраните её\n"
                "3. По этой ссылке можно следить за заявкой позже\n"
                "4. Номер заявки без ссылки статус не откроет",
                "Другое",
                "статус,заявк,ссылк",
            ),
        ]
        for q, a, cat, kw in kb:
            db.session.add(KnowledgeBase(question=q, answer=a, category=cat, keywords=kw))

        db.session.commit()
        print("Demo data loaded:")
        print("  admin / admin123")
        print("  tech  / tech123")
        print(f"  equipment: {len(items)}, tickets: {len(tickets_spec)}")


if __name__ == "__main__":
    from app import create_app

    seed_all(create_app())
