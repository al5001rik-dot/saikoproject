"""ИИ-помощник ScanFix: стоп-слова, база знаний и запасной режим без API."""
from __future__ import annotations

import re
from typing import Any

DANGER_ROOTS = [
    "дым",
    "искр",
    "гар",
    "горит",
    "пахнет",
    "током",
    "бьёт",
    "бьет",
    "проводк",
    "вскры",
    "разобр",
    "замыкан",
    "вздул",
    "перегре",
    "жжёт",
    "жжет",
]

DANGER_MESSAGE = (
    "Не трогайте оборудование. Отойдите от него и немедленно сообщите "
    "ответственному сотруднику. Рекомендации по самостоятельному ремонту "
    "в таких случаях не даются."
)

CATEGORIES = [
    "Не включается",
    "Не печатает",
    "Нет изображения",
    "Нет интернета или ПО",
    "Физическое повреждение",
    "Другое",
]


def _has_danger(text: str) -> bool:
    low = text.lower()
    return any(root in low for root in DANGER_ROOTS)


def _match_kb(text: str, items: list[Any]) -> Any | None:
    low = text.lower()
    best = None
    best_score = 0
    for item in items:
        words = [w.strip() for w in (item.keywords or "").lower().split(",") if w.strip()]
        score = sum(1 for w in words if w in low)
        if score > best_score:
            best_score = score
            best = item
    return best if best_score > 0 else None


def _guess_category(text: str) -> str:
    low = text.lower()
    mapping = [
        ("Не включается", ["не включа", "не запуск", "не грузит", "чёрный экран", "черный экран"]),
        ("Не печатает", ["не печат", "принтер", "картридж", "зажевал", "бумага"]),
        ("Нет изображения", ["нет изображ", "проектор", "нет картин", "пустой экран"]),
        ("Нет интернета или ПО", ["интернет", "сеть", "wi-fi", "wifi", "программа", "софт"]),
        ("Физическое повреждение", ["разбит", "трещин", "упал", "сломан", "погнут"]),
    ]
    for cat, keys in mapping:
        if any(k in low for k in keys):
            return cat
    return "Другое"


def analyze_problem(description: str, kb_items: list[Any], equipment_name: str = "") -> dict:
    """Вернуть ответ помощника. Работает без внешнего API (демо-режим)."""
    text = (description or "").strip()
    if len(text) < 3:
        return {
            "type": "need_info",
            "category": "Другое",
            "danger": False,
            "title": "Нужно уточнение",
            "description": text,
            "recommendations": [],
            "question": "Какое устройство ведёт себя странно и что именно происходит?",
            "source": "fallback",
            "message": None,
        }

    if _has_danger(text):
        return {
            "type": "danger",
            "category": "Физическое повреждение",
            "danger": True,
            "title": "Опасная ситуация с оборудованием",
            "description": text,
            "recommendations": [],
            "question": None,
            "source": "rules",
            "message": DANGER_MESSAGE,
        }

    # Мало данных
    if len(text) < 10 or text.lower() in {"не работает", "сломалось", "проблема", "помогите"}:
        return {
            "type": "need_info",
            "category": "Другое",
            "danger": False,
            "title": "Нужно уточнение по проблеме",
            "description": text,
            "recommendations": [],
            "question": "Опишите подробнее: что именно не работает и что вы уже пробовали?",
            "source": "fallback",
            "message": None,
        }

    kb = _match_kb(text, kb_items)
    category = (kb.category if kb and kb.category else None) or _guess_category(text)
    title = (kb.question if kb else f"Проблема с {equipment_name or 'оборудованием'}")[:80]

    if kb:
        tips = [line.strip(" -•\t") for line in kb.answer.split("\n") if line.strip()]
        tips = [t for t in tips if t][:4]
        return {
            "type": "faq" if "как" in text.lower() else "typical",
            "category": category,
            "danger": False,
            "title": title,
            "description": text,
            "recommendations": tips or [
                "Проверьте кабель питания и розетку",
                "Перезагрузите устройство",
                "Если не помогло — оформите заявку",
            ],
            "question": None,
            "source": "kb",
            "message": "Ответ подготовлен без ИИ (база знаний колледжа).",
        }

    # Универсальные безопасные советы
    generic = {
        "Не включается": [
            "Проверьте, включена ли розетка и плотно ли вставлен кабель питания",
            "Попробуйте другую розетку",
            "Убедитесь, что кнопка питания нажата",
            "Если не помогло — оформите заявку специалисту",
        ],
        "Не печатает": [
            "Проверьте наличие бумаги и индикаторы принтера",
            "Убедитесь, что принтер включён и выбран в системе",
            "Перезапустите задание печати",
            "Если не помогло — оформите заявку",
        ],
        "Нет изображения": [
            "Проверьте кабель HDMI/VGA и источник сигнала",
            "Выберите правильный вход на проекторе/мониторе",
            "Перезагрузите устройство и источник",
            "Если не помогло — оформите заявку",
        ],
        "Нет интернета или ПО": [
            "Проверьте индикатор сети и кабель/Wi‑Fi",
            "Перезагрузите компьютер",
            "Попробуйте открыть другую страницу",
            "Если не помогло — оформите заявку",
        ],
    }.get(
        category,
        [
            "Проверьте кабели и питание",
            "Перезагрузите устройство",
            "Не разбирайте корпус и не чините проводку",
            "Если не помогло — оформите заявку специалисту",
        ],
    )

    # Совсем неизвестная странная проблема
    if re.search(r"розов|по вторник|оперативн|сколько гб|какая у", text.lower()):
        return {
            "type": "unknown",
            "category": category,
            "danger": False,
            "title": f"Запрос по {equipment_name or 'оборудованию'}",
            "description": text,
            "recommendations": [
                "Характеристики смотрите в карточке устройства",
                "Мы не выдумываем технические данные",
                "Оформите заявку — специалист проверит на месте",
            ],
            "question": None,
            "source": "fallback",
            "message": "Информации недостаточно для точных рекомендаций. Обратитесь к специалисту.",
        }

    return {
        "type": "typical",
        "category": category,
        "danger": False,
        "title": title,
        "description": text,
        "recommendations": generic,
        "question": None,
        "source": "fallback",
        "message": "Ответ подготовлен без ИИ.",
    }
